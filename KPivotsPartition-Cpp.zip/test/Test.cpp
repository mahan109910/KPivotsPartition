#include "../src/IPartition.h"
#include "../src/KPivotsPartition.h"
#include <time.h>
#include <iostream>

using namespace std;

int Pivots1[7] = { 0,14,17,20,22,38,40 };
double Pivots2[5] = { 1.6,1.8,2.1,8.2,9.5 };

int arr1[20] = { 4,38,38,2,24,25,25,1,27,1,11,35,22,27,36,31,4,22,33,12 };
double arr2[20] = { 4.7,2.6,7.1,3.8,6.9,1.2,6.7,9.9,3.5,9.4,0.3,1.1,2.2,3.3,7.3,6.4,4.1,1.1,5.3,6.8 };

int correctQ1[14] = { 0,0,0,0,2,4,4,4,11,11,11,11,20,20};
int correctQ2[10] = { 0,0,0,0,0,4,4,4,18,19 };



void testKPivotsPartition(int n, int p, int r,int k)
{
	int pivotsCount = k;
	int indexCount = 2*k;
	int* pivots;
	int* q;
	int* A;

	A = new int[n];

	q = new int[indexCount];
	pivots = new int[k];
	cout << "Initial Array:" << endl;
	for (int i = 0; i < n; i++)
	{
		A[i] = arr1[i];
		cout << A[i] << ", ";
	}
	for (int i = 0;i < pivotsCount;i++) {
		pivots[i] = Pivots1[i];
	}
	IPartition<int>* fwp = new KPivotsPartition<int>();
	
	fwp->partition(A, pivots, q, p, r, pivotsCount);

	cout<<endl<<"q array after partition" << endl << "your\t" << "correct" << endl;
	for (int i = 0;i < indexCount;i++) {
		cout << q[i] << '\t' << correctQ1[i] << endl;
		if (q[i] != correctQ1[i]) {
			throw runtime_error("Incorrect Partition");
		}
	}
}

void testTemplateKPivotsPartition(int n, int p, int r,int k)
{
	int pivotsCount = k;
	int indexCount = 2*k;
	double* pivots;
	int* q;
	double* A;

	A = new double[n];

	q = new int[indexCount];
	pivots = new double[pivotsCount];
	

	cout << "Initial Array:" << endl;
	for (int i = 0; i < n; i++)
	{
		A[i] = arr2[i];
		cout << A[i] << ", ";
	}
	for (int i = 0;i < pivotsCount;i++) {
		pivots[i] = Pivots2[i];
	}
	IPartition<double>* kpp = new KPivotsPartition<double>();

	kpp->partition(A, pivots, q, p, r, pivotsCount);

	cout << endl << "q array after partition" << endl << "your\t" << "correct" << endl;
	for (int i = 0;i < indexCount;i++) {
		cout << q[i] << '\t' << correctQ2[i] << endl;
		if (q[i] != correctQ2[i]) {
			throw runtime_error("Incorrect Partition");
		}
	}
}

int main()
{
	cout << endl
		<< "Test  kPivots partition with p = start of arr and r = end of arr with 7 pivots" << endl;
	testKPivotsPartition(20, 0, 19, 7);

	cout << endl
		<< "Test template kPivots partition with p = start of arr and r = end of arr with 5 pivots " << endl;
	testTemplateKPivotsPartition(20, 0, 19,  5);
	cout << endl << "Excellent!!";
	return 0;
}
