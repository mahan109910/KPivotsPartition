// Copyright (C) Kamaledin Ghiasi-Shirazi, Ferdowsi Univerity of Mashhad, Nov 28, 2024 (1403 Hijri Shamsi)
//
// 	Author:		Kamaledin Ghiasi-Shirazi 
//				Pourya Alvani
#pragma once


template <class T>
class KPivotsPartition :public IPartition<T>
{

public :
	virtual void partition (T* A, T* pivots, int* q, int p, int r, int k) {
		//write your code here.
	}
};
