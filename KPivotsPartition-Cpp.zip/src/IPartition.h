#pragma once

template <class T>
class IPartition
{
public:

	virtual void partition(T* A, T* pivots, int* q, int p, int r, int k) = 0;

};